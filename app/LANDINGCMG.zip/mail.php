<?php

// $recepient = "kola.stani@gmail.com";
// $sitename = "Название сайта";

// $name = trim($_GET["name"]);
// $phone = trim($_GET["phone"]);

// $pagetitle = "Новая заявка с сайта \"$sitename\"";
// $message = "Имя: $name \nТелефон: $phone \n";
// mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");
echo "<pre>";
	print_r($_POST);
echo "</pre>";
?>